<style>
<?php 
    include "../style/footer.css";
?>
</style>
<footer>
    <p>Desenvolvido por Guilherme Shimada Pereira</p>
</footer>