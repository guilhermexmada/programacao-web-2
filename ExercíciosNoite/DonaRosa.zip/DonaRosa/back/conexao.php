<?php 
    $conexao = mysqli_connect('localhost', 'root', '', 'donarrosa');
    mysqli_set_charset($conexao, 'utf8');   
?>